<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VisitsController;
use App\Http\Controllers\PractitionersController;
use \App\Http\Controllers\expense_sheetsController;
use App\Http\Controllers\expense_sheet_statesController;
use App\Http\Controllers\expense_proofsController;
use App\Http\Controllers\expense_statesController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/users', function (Request $request) {
    return $request->user();
});

Route::get("/visits",[VisitsController::class,'get']);
Route::get("/visits/{id}",[VisitsController::class,'getOne']);
Route::get("/medicines",[\App\Http\Controllers\MedicinesController::class,'take']);
Route::get("/medicines/{id}",[\App\Http\Controllers\MedicinesController::class,'takeOne']);
Route::get("/practitioners",[\App\Http\Controllers\PractitionersController::class,'catch']);
Route::get("/practitioners/{id}",[\App\Http\Controllers\PractitionersController::class,'catchOne']);
Route::post("/visits/add",[VisitsController::class,'add']);

Route::get("/sheets",[\App\Http\Controllers\expense_sheetsController::class,'getExpenses_sheets']);
Route::get("/sheets/{id}",[\App\Http\Controllers\expense_sheetsController::class,'getExpense_sheetById']);
Route::get("/sheetsStates",[\App\Http\Controllers\expense_sheet_statesController::class,'getExpenses_sheets_states']);
Route::get("/sheetsStates/{id}",[\App\Http\Controllers\expense_sheet_statesController::class,'getExpense_sheet_statesById']);
Route::get("/proofs",[\App\Http\Controllers\expense_proofsController::class,'getExpenses_proofs']);
Route::get("/proofs/{id}",[\App\Http\Controllers\expense_proofsController::class,'getExpense_proofById']);
Route::get("/expensesStates",[\App\Http\Controllers\expense_statesController::class,'getExpenses_states']);
Route::get("/expensesStates/{id}",[\App\Http\Controllers\expense_statesController::class,'getExpense_statesById']);
Route::get("/sheetsInProgress",[\App\Http\Controllers\expense_sheetsController::class,'getExpenses_sheetsCreated']);
Route::get("/expenseDate/{date}",[\App\Http\Controllers\expense_sheetsController::class,'getExpense_sheetByDate']);

route::post("sheets/add",[expense_sheetsController::class,'add']);
route::post("proofs/add",[expense_proofsController::class,'add']);

route::delete("sheets/delete/{id}",[expense_sheetsController::class,'delete']);
