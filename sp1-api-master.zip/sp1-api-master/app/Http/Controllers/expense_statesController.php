<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\expense_states;
class expense_statesController extends Controller
{
    function getExpenses_states()
    {
        return expense_states::all();
    }
    function getExpense_statesById($id){
        return expense_states::find($id);
    }

}
