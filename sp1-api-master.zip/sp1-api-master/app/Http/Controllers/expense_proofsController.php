<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\expense_proofs;
class expense_proofsController extends Controller
{
    function getExpenses_proofs(){
        return expense_proofs::all();
    }
    function getExpense_proofById($id){
        return expense_proofs::find($id);
    }
    function add(Request $request)

    {
        //	id	description	filePath	expenseProofTypes_id	uploadDate
        $proofs = new expense_proofs;
        $proofs->description = $request->description;
        $proofs->filePath = $request->filePath;
        $proofs->expenseProofTypes_id = $request->expenseProofTypes_id;
        $res = $proofs->save();
        if ($res) {
            return ["result " => "success"];
        } else {
            return ["result " => "fail"];
        }
    }

}
