<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\expense_sheets;
use PharIo\Manifest\Type;

class expense_sheetsController extends Controller
{
    function getExpenses_sheets()
    {
        $return=[];
        foreach(expense_sheets::all() as $item){
            $return[]=$item->jsonify();
        }
        return $return;
    }
    function getExpense_sheetById($id)
    {
        return expense_sheets::find($id);
    }
    function getExpenses_sheetsCreated()
    {

        //return expense_sheets::where('sheetState_id', 1)->get();
        /*$return=[];
        foreach(expense_sheets::where('sheetState_id', 1)->get() as $item){
            $return[]=$item->jsonify();
        }
        return $return;*/


        foreach(expense_sheets::all() as $item){
            $return[]=$item->stringfy();
        }
        return expense_sheets::where('sheetState_id', 1)->get();

    }
    function add(Request $request)

    {
            //Full texts	id	employee_id	ref	unit	calculatedAmount	sheetState_id	creationDate	modificationDate
            $sheets = new expense_sheets;
            $sheets->employee_id = $request->employee_id;
            $sheets->ref = $request->ref;
            $sheets->unit = $request->unit;
            $sheets->calculatedAmount = $request->calculatedAmount;
            $sheets->sheetState_id = $request->sheetState_id;
            $res = $sheets->save();
            if ($res) {
                return ["result " => "success"];
            } else {
                return ["result " => "fail"];
            }
    }
    function delete($id){

        expense_sheets::where('id',$id)->delete();

    }

//    function getExpense_sheetByDate($date)
//    {
//        return expense_sheets::find($date);
//    }
}
