<?php

namespace App\Http\Controllers;

use App\Models\expense_sheet_states;
use Illuminate\Http\Request;

class expense_sheet_statesController extends Controller
{
    function getExpenses_sheets_states()
    {
        return expense_sheet_states::all();
    }
    function getExpense_sheet_statesById($id)
    {
        return expense_sheet_states::find($id);
    }

}
