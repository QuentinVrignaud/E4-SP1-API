<?php

namespace App\Models;

use App\Traits\Jsonify;
use App\Traits\Stringfy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class expense_sheets extends Model
{
    use HasFactory,Jsonify,Stringfy;
    public $timestamp=false;
}
