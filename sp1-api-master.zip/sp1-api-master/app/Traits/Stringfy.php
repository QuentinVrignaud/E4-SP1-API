<?php


namespace App\Traits;

trait Stringfy
{
    public function stringfy()
    {
    $obj = new \stdClass();
    //var_dump($obj);
    $vars = $this->attributesToArray();
    //var_dump($vars);
    foreach ($vars as $key=>$value) {;
            $obj->$key=strval($value);
    }
    return $obj;
    }
}
