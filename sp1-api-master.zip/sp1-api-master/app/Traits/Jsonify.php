<?php


namespace App\Traits;


trait Jsonify
{
    public function jsonify()
    {
        $obj = new \stdClass();
        //var_dump($obj);
        $vars = $this->attributesToArray();
        //var_dump($vars);
        foreach ($vars as $key=>$value) {
            if(null==$value){
                $obj->$key='null';
            }else{
                $obj->$key=$value;
            }
        }
        return $obj;
    }

}
